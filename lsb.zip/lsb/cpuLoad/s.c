#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 9000
#define BUFFER_SIZE 1024

// Function to get CPU load from /proc/loadavg
void get_cpu_load(char *buffer, size_t buffer_size) {
    FILE *fp = fopen("/proc/loadavg", "r");
    if (fp == NULL) {
        perror("Failed to open /proc/loadavg");
        snprintf(buffer, buffer_size, "CPU Load: Unable to fetch");
        return;
    }

    float load1, load5, load15;
    fscanf(fp, "%f %f %f", &load1, &load5, &load15);
    fclose(fp);

    snprintf(buffer, buffer_size, "CPU Load: %.2f (1 min), %.2f (5 min), %.2f (15 min)", load1, load5, load15);
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE];

    // Create server socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind the socket to the port
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_socket, 5) < 0) {
        perror("Listen failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    printf("Server is running on port %d...\n", PORT);

    while (1) {
        // Accept a client connection
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_addr_len);
        if (client_socket < 0) {
            perror("Client connection failed");
            continue;
        }

        printf("Client connected.\n");

        // Get CPU load
        get_cpu_load(buffer, sizeof(buffer));

        // Send CPU load to client
        send(client_socket, buffer, strlen(buffer), 0);

        printf("Sent to client: %s\n", buffer);

        // Close client connection
        close(client_socket);
        printf("Client disconnected.\n");
    }

    close(server_socket);
    return 0;
}
