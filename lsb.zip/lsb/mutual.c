#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAX_PROCESSES 10

typedef struct {
    int process_id;
    int timestamp;
} Request;

typedef struct {
    int logical_clock;
    bool in_critical_section;
    int total_processes;
    int responses_received;
    Request request_queue[MAX_PROCESSES];
    int queue_count;
} Process;

// Function to increment the logical clock
void increment_clock(Process *process) {
    process->logical_clock++;
}

// Function to handle incoming request
void handle_request(Process *process, Request incoming_request) {
    increment_clock(process);
    if (process->in_critical_section || 
        (process->logical_clock < incoming_request.timestamp) ||
        (process->logical_clock == incoming_request.timestamp && process->process_id < incoming_request.process_id)) {
        printf("Process %d: Adding request from Process %d to queue.\n", process->process_id, incoming_request.process_id);
        process->request_queue[process->queue_count++] = incoming_request;
    } else {
        printf("Process %d: Granting permission to Process %d.\n", process->process_id, incoming_request.process_id);
        process->responses_received++;
    }
}

// Function to request critical section access
void request_critical_section(Process *process) {
    increment_clock(process);
    printf("Process %d: Requesting critical section at timestamp %d.\n", process->process_id, process->logical_clock);
    process->responses_received = 0;

    for (int i = 0; i < process->total_processes; i++) {
        if (i != process->process_id) {
            printf("Process %d: Sending request to Process %d.\n", process->process_id, i);
        }
    }
}

// Function to release critical section
void release_critical_section(Process *process) {
    process->in_critical_section = false;
    printf("Process %d: Releasing critical section.\n", process->process_id);

    // Grant permission to queued requests
    for (int i = 0; i < process->queue_count; i++) {
        printf("Process %d: Granting permission to Process %d from queue.\n", process->process_id, process->request_queue[i].process_id);
    }

    process->queue_count = 0;
}

int main() {
    int choice;
    Process processes[MAX_PROCESSES];
    int total_processes;

    printf("Enter the total number of processes: ");
    scanf("%d", &total_processes);

    for (int i = 0; i < total_processes; i++) {
        processes[i].process_id = i;
        processes[i].logical_clock = 0;
        processes[i].in_critical_section = false;
        processes[i].total_processes = total_processes;
        processes[i].responses_received = 0;
        processes[i].queue_count = 0;
    }

    printf("Choose algorithm for simulation:\n");
    printf("1. Lamport's Algorithm\n");
    printf("2. Ricart-Agrawala Algorithm\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch (choice) {
        case 1:
            printf("\nSimulating Lamport's Algorithm:\n");
            request_critical_section(&processes[0]);
            handle_request(&processes[1], (Request){0, processes[0].logical_clock});
            handle_request(&processes[2], (Request){0, processes[0].logical_clock});
            processes[0].in_critical_section = true;
            release_critical_section(&processes[0]);
            break;

        case 2:
            printf("\nSimulating Ricart-Agrawala Algorithm:\n");
            request_critical_section(&processes[0]);
            handle_request(&processes[1], (Request){0, processes[0].logical_clock});
            handle_request(&processes[2], (Request){0, processes[0].logical_clock});
            processes[0].in_critical_section = true;
            release_critical_section(&processes[0]);
            break;

        default:
            printf("Invalid choice!\n");
            break;
    }

    return 0;
}
