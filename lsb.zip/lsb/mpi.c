#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define ARRAY_SIZE 100

// Function to compute the sum of an array chunk
int compute_sum(int *array, int size) {
    int sum = 0;
    for (int i = 0; i < size; i++) {
        sum += array[i];
    }
    return sum;
}

int main(int argc, char *argv[]) {
    int rank, size;
    int array[ARRAY_SIZE];
    int local_sum = 0, global_sum = 0;
    int chunk_size;

    // Initialize MPI environment
    MPI_Init(&argc, &argv);

    // Get the rank (process ID) and the total number of processes
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Master process initializes the array
    if (rank == 0) {
        printf("Master process initializing array...\n");
        for (int i = 0; i < ARRAY_SIZE; i++) {
            array[i] = i + 1; // Array contains numbers 1 to ARRAY_SIZE
        }
    }

    // Calculate the chunk size for each process
    chunk_size = ARRAY_SIZE / size;

    // Allocate memory for the local chunk
    int *local_array = (int *)malloc(chunk_size * sizeof(int));

    // Scatter the array to all processes
    MPI_Scatter(array, chunk_size, MPI_INT, local_array, chunk_size, MPI_INT, 0, MPI_COMM_WORLD);

    // Each process computes the sum of its chunk
    local_sum = compute_sum(local_array, chunk_size);
    printf("Process %d computed local sum: %d\n", rank, local_sum);

    // Gather all local sums to the master process
    MPI_Reduce(&local_sum, &global_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    // Master process displays the total sum
    if (rank == 0) {
        printf("Global sum computed by master process: %d\n", global_sum);
    }

    // Clean up
    free(local_array);

    // Finalize MPI environment
    MPI_Finalize();

    return 0;
}




// sudo apt-get install mpich
//mpicc -o mpi_sum mpi_sum.c
//mpirun -np 4 ./mpi_sum
