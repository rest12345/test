#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>    // For O_CREAT, O_EXCL
#include <sys/mman.h> // For mmap, shm_open
#include <sys/stat.h> // For mode constants
#include <unistd.h>   // For close
#include <semaphore.h>

#define SHARED_MEM_NAME "/shared_mem_example"
#define SEMAPHORE_NAME "/semaphore_example"
#define SHARED_MEM_SIZE sizeof(int)

int main() {
    int shm_fd;           // Shared memory file descriptor
    int *shared_counter;  // Pointer to shared memory
    sem_t *sem;           // Semaphore

    // Open existing shared memory
    shm_fd = shm_open(SHARED_MEM_NAME, O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("Failed to open shared memory");
        exit(EXIT_FAILURE);
    }

    // Map shared memory into process address space
    shared_counter = mmap(0, SHARED_MEM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shared_counter == MAP_FAILED) {
        perror("Failed to map shared memory");
        close(shm_fd);
        exit(EXIT_FAILURE);
    }

    // Open existing semaphore
    sem = sem_open(SEMAPHORE_NAME, 0);
    if (sem == SEM_FAILED) {
        perror("Failed to open semaphore");
        munmap(shared_counter, SHARED_MEM_SIZE);
        close(shm_fd);
        exit(EXIT_FAILURE);
    }

    printf("Client is running. Reading counter value...\n");

    // Synchronize access using semaphore
    sem_wait(sem); // Wait (decrement semaphore)

    // Critical section: Read shared counter
    printf("Counter value: %d\n", *shared_counter);

    sem_post(sem); // Signal (increment semaphore)

    // Clean up resources
    munmap(shared_counter, SHARED_MEM_SIZE);
    close(shm_fd);
    sem_close(sem);

    return 0;
}
