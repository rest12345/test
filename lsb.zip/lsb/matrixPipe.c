#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define ROWS 3
#define COLS 3

// Function to print a matrix
void print_matrix(int matrix[ROWS][COLS]) {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int pipe1[2], pipe2[2]; // Two pipes: pipe1 for parent->child, pipe2 for child->parent
    pid_t pid;

    // Matrices
    int matrix1[ROWS][COLS] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}};
    int matrix2[ROWS][COLS] = {
        {9, 8, 7},
        {6, 5, 4},
        {3, 2, 1}};
    int result[ROWS][COLS];

    // Create pipe1
    if (pipe(pipe1) == -1) {
        perror("Pipe1 creation failed");
        exit(EXIT_FAILURE);
    }

    // Create pipe2
    if (pipe(pipe2) == -1) {
        perror("Pipe2 creation failed");
        exit(EXIT_FAILURE);
    }

    // Create child process
    pid = fork();
    if (pid < 0) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent Process
        close(pipe1[0]); // Close reading end of pipe1
        close(pipe2[1]); // Close writing end of pipe2

        // Send matrices to child process via pipe1
        write(pipe1[1], matrix1, sizeof(matrix1));
        write(pipe1[1], matrix2, sizeof(matrix2));
        close(pipe1[1]); // Close writing end of pipe1

        // Receive result matrix from child process via pipe2
        read(pipe2[0], result, sizeof(result));
        close(pipe2[0]); // Close reading end of pipe2

        // Print the resulting matrix
        printf("Parent Process: Resultant Matrix (Sum of Matrices):\n");
        print_matrix(result);
    } else {
        // Child Process
        close(pipe1[1]); // Close writing end of pipe1
        close(pipe2[0]); // Close reading end of pipe2

        // Read matrices from parent process via pipe1
        int received_matrix1[ROWS][COLS];
        int received_matrix2[ROWS][COLS];
        read(pipe1[0], received_matrix1, sizeof(received_matrix1));
        read(pipe1[0], received_matrix2, sizeof(received_matrix2));
        close(pipe1[0]); // Close reading end of pipe1

        // Compute the sum of the matrices
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                result[i][j] = received_matrix1[i][j] + received_matrix2[i][j];
            }
        }

        // Send the result matrix back to parent process via pipe2
        write(pipe2[1], result, sizeof(result));
        close(pipe2[1]); // Close writing end of pipe2
    }

    return 0;
}
