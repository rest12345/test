#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>
#include <dirent.h>
#include <unistd.h>
#include <limits.h>

#define MAX_USERS 100
#define MAX_PATH_LENGTH 1024

// Structure to store file information
typedef struct {
    char owner[256];
    off_t size;
} FileInfo;

// Function to get file owner
void get_file_owner(uid_t uid, char *owner) {
    struct passwd *pwd = getpwuid(uid);
    if (pwd != NULL) {
        strncpy(owner, pwd->pw_name, 256);
    } else {
        strncpy(owner, "unknown", 256);
    }
}

// Function to iterate through files in the directory (Mapper)
int map_files(const char *directory, FileInfo *fileInfos, int *count) {
    DIR *dir;
    struct dirent *entry;
    struct stat file_stat;
    char filepath[MAX_PATH_LENGTH];

    *count = 0;
    dir = opendir(directory);
    if (dir == NULL) {
        perror("opendir");
        return -1;
    }

    while ((entry = readdir(dir)) != NULL) {
        // Skip directories
        if (entry->d_type == DT_DIR) {
            continue;
        }

        // Build the full path of the file
        snprintf(filepath, MAX_PATH_LENGTH, "%s/%s", directory, entry->d_name);

        // Get file stats
        if (stat(filepath, &file_stat) == 0) {
            get_file_owner(file_stat.st_uid, fileInfos[*count].owner);
            fileInfos[*count].size = file_stat.st_size;
            (*count)++;
        }
    }

    closedir(dir);
    return 0;
}

// Function to reduce the maximum file size
off_t reduce_max_size(FileInfo *fileInfos, int count) {
    off_t max_size = 0;
    for (int i = 0; i < count; i++) {
        if (fileInfos[i].size > max_size) {
            max_size = fileInfos[i].size;
        }
    }
    return max_size;
}

// Function to find owners of files with the maximum size (Filter)
void find_owners_with_max_size(FileInfo *fileInfos, int count, off_t max_size, char owners[MAX_USERS][256], int *owner_count) {
    *owner_count = 0;
    for (int i = 0; i < count; i++) {
        if (fileInfos[i].size == max_size) {
            strncpy(owners[*owner_count], fileInfos[i].owner, 256);
            (*owner_count)++;
        }
    }
}

int main() {
    char current_directory[MAX_PATH_LENGTH];
    FileInfo fileInfos[MAX_USERS];
    char owners[MAX_USERS][256];
    int file_count, owner_count;
    off_t max_size;

    // Get the current working directory
    if (getcwd(current_directory, sizeof(current_directory)) == NULL) {
        perror("getcwd");
        return 1;
    }

    // Map files to gather file info
    if (map_files(current_directory, fileInfos, &file_count) != 0) {
        fprintf(stderr, "Error mapping files\n");
        return 1;
    }

    // Reduce to find the maximum file size
    max_size = reduce_max_size(fileInfos, file_count);

    // Filter to find owners of files with the maximum size
    find_owners_with_max_size(fileInfos, file_count, max_size, owners, &owner_count);

    // Output the results
    printf("Maximum file size: %ld bytes\n", max_size);
    printf("Owners of the largest file(s):\n");
    for (int i = 0; i < owner_count; i++) {
        printf("- %s\n", owners[i]);
    }

    return 0;
}


// gcc -o map_reduce_max_file map_reduce_max_file.c
// ./map_reduce_max_file
