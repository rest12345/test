#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define BUFFER_SIZE 1024

// Function to manually concatenate two strings without using string library functions
void manual_concatenate(char *dest, const char *src) {
    // Find the end of the first string
    while (*dest) {
        dest++;
    }
    // Append the second string
    while (*src) {
        *dest = *src;
        dest++;
        src++;
    }
    // Null-terminate the resulting string
    *dest = '\0';
}

int main() {
    int pipe1[2], pipe2[2]; // Two pipes: pipe1 for parent->child, pipe2 for child->parent
    pid_t pid;
    char buffer[BUFFER_SIZE];
    char additional_string[] = " - Concatenated by Process 2";

    // Create pipe1
    if (pipe(pipe1) == -1) {
        perror("Pipe1 creation failed");
        exit(EXIT_FAILURE);
    }

    // Create pipe2
    if (pipe(pipe2) == -1) {
        perror("Pipe2 creation failed");
        exit(EXIT_FAILURE);
    }

    // Create child process
    pid = fork();
    if (pid < 0) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent Process (Process 1)
        close(pipe1[0]); // Close reading end of pipe1
        close(pipe2[1]); // Close writing end of pipe2

        // Get input string from user
        printf("Process 1: Enter a string: ");
        fgets(buffer, BUFFER_SIZE, stdin);
        buffer[strcspn(buffer, "\n")] = '\0'; // Remove newline character

        // Send string to Process 2 via pipe1
        write(pipe1[1], buffer, strlen(buffer) + 1);
        close(pipe1[1]); // Close writing end of pipe1

        // Read concatenated string from Process 2 via pipe2
        read(pipe2[0], buffer, BUFFER_SIZE);
        printf("Process 1: Received concatenated string: %s\n", buffer);
        close(pipe2[0]); // Close reading end of pipe2
    } else {
        // Child Process (Process 2)
        close(pipe1[1]); // Close writing end of pipe1
        close(pipe2[0]); // Close reading end of pipe2

        // Read string from Process 1 via pipe1
        read(pipe1[0], buffer, BUFFER_SIZE);
        close(pipe1[0]); // Close reading end of pipe1

        // Concatenate the received string with the additional string manually
        manual_concatenate(buffer, additional_string);

        // Send the concatenated string back to Process 1 via pipe2
        write(pipe2[1], buffer, strlen(buffer) + 1);
        close(pipe2[1]); // Close writing end of pipe2
    }

    return 0;
}



//gcc -o process_pipe process_pipe.c
//./process_pipe
