#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 9000
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 100

typedef struct {
    int client_id;
    char ip_address[INET_ADDRSTRLEN];
    int port;
} ClientInfo;

void display_master_table(ClientInfo *table, int count) {
    printf("Updated Master Table:\n");
    printf("Client ID\tIP Address\tPort\n");
    for (int i = 0; i < count; i++) {
        printf("%d\t\t%s\t%d\n", table[i].client_id, table[i].ip_address, table[i].port);
    }
}

int main() {
    int client_socket;
    struct sockaddr_in server_addr;
    ClientInfo master_table[MAX_CLIENTS];
    int client_count;

    // Create the client socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure the server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);

    // Connect to the server
    if (connect(client_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection to server failed");
        close(client_socket);
        exit(EXIT_FAILURE);
    }

    // Receive the updated master table from the server
    recv(client_socket, &client_count, sizeof(client_count), 0);
    recv(client_socket, master_table, sizeof(master_table[0]) * client_count, 0);

    // Display the updated master table
    display_master_table(master_table, client_count);

    close(client_socket);
    return 0;
}
